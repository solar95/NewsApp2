package com.example.solar.newsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class NewsAdapter  extends ArrayAdapter<NewsArticle> {

    public NewsAdapter(Context context, List<NewsArticle> NewsArticles) {
        super(context, 0, NewsArticles);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listItemView = convertView;
        if (listItemView == null) { listItemView = LayoutInflater.from(getContext()).inflate(
             R.layout.item, parent, false);
        }

        NewsArticle currentNewsArticle = getItem(position);

        TextView title = listItemView.findViewById(R.id.title);
        title.setText(currentNewsArticle.getTitle());

        TextView date = listItemView.findViewById(R.id.date);
        date.setText(currentNewsArticle.getDate());

        TextView content = listItemView.findViewById(R.id.textContent);
        content.setText(currentNewsArticle.getContent());

        TextView sectionName = listItemView.findViewById(R.id.section);
        sectionName.setText(currentNewsArticle.getSection());

        return listItemView;
    }

}
