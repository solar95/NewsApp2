package com.example.solar.newsapp;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<NewsArticle>> {
    private static final String USGS_REQUEST_URL = "https://content.guardianapis.com/search?";
    private NewsAdapter adapter;
    ListView NewsArticleListView;
    TextView noNewsArticleText;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        NewsArticleListView = findViewById(R.id.list);
        progressBar = findViewById(R.id.progress_bar);
        noNewsArticleText = findViewById(R.id.empty_view);
        adapter = new NewsAdapter(this, new ArrayList<NewsArticle>());
        NewsArticleListView.setAdapter(adapter);
        NewsArticleListView.setEmptyView(noNewsArticleText);

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        if (isConnected) {
            getLoaderManager().initLoader(0, null, this);
        } else {
            progressBar.setVisibility(View.GONE);
            noNewsArticleText.setText(R.string.no_internet);
        }
        NewsArticleListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                NewsArticle currentNewsArticle = adapter.getItem(position);
                Uri NewsArticleUri = Uri.parse(currentNewsArticle.getLink());
                Intent websiteIntent = new Intent(Intent.ACTION_VIEW, NewsArticleUri);
                startActivity(websiteIntent);
            }
        });
    }

    @Override
    public Loader<List<NewsArticle>> onCreateLoader(int id, Bundle args) {
        String TAG = "URI";
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);

        Boolean books = sharedPrefs.getBoolean("books",false);
        Boolean business = sharedPrefs.getBoolean("business",false);
        Boolean fashion = sharedPrefs.getBoolean("fashion",false);
        Boolean games = sharedPrefs.getBoolean("games",false);
        Boolean lifeandstyle = sharedPrefs.getBoolean("lifeandstyle",false);
        Boolean money = sharedPrefs.getBoolean("money",false);
        Boolean science = sharedPrefs.getBoolean("science",false);
        Boolean sport = sharedPrefs.getBoolean("sport",false);
        Boolean technology = sharedPrefs.getBoolean("technology",false);
        Boolean travel = sharedPrefs.getBoolean("travel",false);

        String numNewsArticles = sharedPrefs.getString(
                getString(R.string.settings_num_articles_key),
                getString(R.string.settings_num_articles_default));

        Uri baseUri = Uri.parse(USGS_REQUEST_URL);

        Uri.Builder uriBuilder = baseUri.buildUpon();

        String sections = "";
        if(books){
            sections += "books|";
        }
        if(business){
            sections += "business|";
        }
        if(fashion){
            sections += "fashion|";
        }
        if(games){
            sections += "games|";
        }
        if(lifeandstyle){
            sections += "lifeandstyle|";
        }
        if(money){
            sections += "money|";
        }
        if(science){
            sections += "science|";
        }
        if(sport){
            sections += "sport|";
        }
        if(technology){
            sections += "technology|";
        }
        if(travel){
            sections += "travel|";
        }

        if(sections.endsWith("|")){
            sections = sections.substring(0, sections.length()-1) + "";
        }
        if (!sections.isEmpty()){
            uriBuilder.appendQueryParameter("section", sections);
        }
        uriBuilder.appendQueryParameter("page-size", numNewsArticles);
        uriBuilder.appendQueryParameter("show-fields", "thumbnail,byline");
        uriBuilder.appendQueryParameter("api-key", "test");
        Log.d(TAG, "uriBuilder: " + uriBuilder.toString());
        return new NewsLoader(this, uriBuilder.toString());
    }

    @Override
    public void onLoadFinished(Loader<List<NewsArticle>> loader, List<NewsArticle> NewsArticles) {
        noNewsArticleText.setText(R.string.no_article);
        // Clear the adapter of previous NewsArticle data
        adapter.clear();

        // If there is a valid list of {@link NewsArticle}s, then add them to the adapter's
        // data set. This will trigger the ListView to update.
        if (NewsArticles != null && !NewsArticles.isEmpty()) {
            adapter.addAll(NewsArticles);
        }
        progressBar.setVisibility(View.GONE);
    }

    @Override
    public void onLoaderReset(Loader<List<NewsArticle>> loader) {
        adapter.clear();
        getLoaderManager().restartLoader(0, null, this);
    }

}
